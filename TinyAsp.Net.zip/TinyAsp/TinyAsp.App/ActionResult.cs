﻿namespace TinyAsp.App
{
    public abstract class ActionResult
	{
		public abstract string ExecuteResult();
	}
}
